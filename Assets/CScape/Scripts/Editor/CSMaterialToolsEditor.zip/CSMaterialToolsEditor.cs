﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
namespace CScape
{
    [CustomEditor(typeof(CSMaterialTools))]
    public class CSMaterialToolsEditor : Editor
    {

        void OnEnable()
        {
            CSMaterialTools bm = (CSMaterialTools)target;




        }

        public void OnSceneGUI()
        {
            CSMaterialTools bm = (CSMaterialTools)target;


        }

        public override void OnInspectorGUI()
        {
            CSMaterialTools mt = (CSMaterialTools)target;

            if (GUILayout.Button("Compile only styles"))
            {
                mt.CreateNormal();
            }

            if (GUILayout.Button("Compile all textures"))
            {
                mt.CreateNormal();
                mt.CreateMaterialsNew();
                mt.CreateBlinds();
                mt.CreateStreets();
                mt.CreateDirt();
                mt.CreateInt();
            }



        }
            // Use this for initialization

    }
}
